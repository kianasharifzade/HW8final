#include <stdio.h>
#include <stdlib.h>
 //kiana sharifzadeh 40223043

struct time {
    int min;
    int sec;
};

struct runner {
    char firstName[30];
    char lastName[30];
    char id[10];
    struct time* record;
    struct time runnigTime;
};

int main() {
    int n;
    printf("enter the number of runners : ");
    scanf("%d", &n);
    struct runner p[n];
    struct runner temp; //for sorting
    for (int i = 0; i < n; i++) {
        printf("enter name %d :  \n", i + 1);
        scanf("%s", p[i].firstName);
        printf("enter last name %d : \n", i + 1);
        scanf("%s", p[i].lastName);
        printf("enter id %d : \n", i + 1);
        scanf("%s", p[i].id);
        p[i].record = (struct time*)malloc(sizeof(struct time));
        printf("enter record time minute %d \n", i + 1);
        scanf("%d", &p[i].record->min);
        printf("enter record time second %d \n", i + 1);
        scanf("%d", &p[i].record->sec);
        printf("enter running time minute %d : \n", i + 1);
        scanf("%d", &p[i].runnigTime.min);
        printf("enter running time second %d : \n", i + 1);
        scanf("%d", &p[i].runnigTime.sec);
    }

    int runSec[n]; //for comparing to find the winner of this match
    for (int i = 0; i < n; i++) {
        runSec[i] = ((p[i].runnigTime.min) * 60) + p[i].runnigTime.sec;
    }

    int mini = runSec[0];
    int winner;
    for (int j = 1; j < n; j++) {
        if (mini > runSec[j]) {
            mini = runSec[j];
            winner = j; //winner's number in p[]
        }
    }

    printf("winner's name:%s\twinner's lastname:%s\n", p[winner].firstName, p[winner].lastName);
    int bestRec = ((p[winner].record->min) * 60) + p[winner].record->sec;
    if (mini < bestRec) {
        printf("runner achieved a new record\n");
    }

    int runnerRec[n];
    int counter = 0;
    for (int i = 0; i < n; i++) {
        runnerRec[i] =((p[i].record->min) * 60) + p[i].record->sec; //for comparing to see if the winner has beaten the total record
        if (mini > runnerRec[i])
            counter++;
    }

    if (counter == 0) {
        printf("runner has beaten other runners's records\n");
    }

    for (int i = 0; i < n; i++) { //sort

        for (int j = i + 1; j < n; j++) {
            if (runSec[i] > runSec[j]) {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }

    printf("first name:\t last name:\t id:\t record:\t\t running time:\n");
    for (int i = 0; i < n; i++) {
        printf("%s\t\t ", p[i].firstName);
        printf("%s\t\t ", p[i].lastName);
        printf("%s\t ", p[i].id);
        printf("%d min and ", p[i].record->min);
        printf("%d sec\t ", p[i].record->sec);
        printf("%d min and ", p[i].runnigTime.min);
        printf("%d sec\n ", p[i].runnigTime.sec);
        free(p[i].record);
    }

    return 0;
}